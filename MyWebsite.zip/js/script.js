document.getElementById("changeColorBtn").onclick = function(){
    document.body.style.backgroundColor = "#dfffe2";
};
